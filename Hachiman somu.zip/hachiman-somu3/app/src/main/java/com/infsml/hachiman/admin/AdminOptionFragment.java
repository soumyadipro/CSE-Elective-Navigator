package com.infsml.hachiman.admin;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.infsml.hachiman.R;
import com.infsml.hachiman.Utility;
import com.infsml.hachiman.databinding.AdminHomeElementBinding;
import com.infsml.hachiman.databinding.AdminTitleElementBinding;
import com.infsml.hachiman.databinding.FragmentAdminOptionBinding;

import org.json.JSONArray;
import org.json.JSONObject;

public class AdminOptionFragment extends Fragment {
    NavController navController;
    Bundle bundle;
    String username = null;
    String auth_token = null;
    String event = null;

    public AdminOptionFragment() {
    }
    public static AdminOptionFragment newInstance(String param1, String param2) {
        AdminOptionFragment fragment = new AdminOptionFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }
    FragmentAdminOptionBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAdminOptionBinding.inflate(inflater,container,false);
        navController = Navigation.findNavController(requireActivity(), R.id.fragmentContainerView);
        bundle = getArguments();
        assert bundle!=null;
        username = bundle.getString("username");
        auth_token = bundle.getString("auth_token");
        event = bundle.getString("event");
        binding.addBtn.setOnClickListener(v->{
            if(optionData!=null) {
                navController.navigate(R.id.action_adminOptionFragment_to_adminAddOptionFragment, bundle);
            }
        });
        binding.csvBtn.setOnClickListener(v->{
            if(optionData!=null) {
                navController.navigate(R.id.action_adminOptionFragment_to_adminCsvOptionFragment, bundle);
            }
        });

        binding.recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        final OptionAdapter optionAdapter = new OptionAdapter();
        binding.recyclerView.setAdapter(optionAdapter);
        fetchOptionData(()->{
            optionAdapter.updateData();
        });
        return binding.getRoot();
    }
    JSONObject optionData;
    public void fetchOptionData(Runnable runnable) {
        (new Thread() {
            @Override
            public void run() {
                try {
                    if(optionData==null) {
                        JSONObject payload = new JSONObject();
                        payload.put("username", username);
                        payload.put("auth_token", auth_token);
                        payload.put("event", event);
                        optionData = Utility.postJSON(
                                Utility.api_base + "/get-option-admin",
                                payload.toString()
                        );
                    }
                    requireActivity().runOnUiThread(runnable);
                } catch (Exception e) {
                    Log.e("Hachiman", "Error", e);
                }
            }
        }).start();
    }
    public class OptionAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
        public class VHtitle extends RecyclerView.ViewHolder{
            TextView textView;
            AdminTitleElementBinding binding;
            public VHtitle(AdminTitleElementBinding binding){
                super(binding.getRoot());
                this.textView=binding.title;
                this.binding = binding;
            }
        }
        public class VHoption extends RecyclerView.ViewHolder{
            AdminHomeElementBinding binding1;
            boolean btn_vis = false;
            public VHoption(AdminHomeElementBinding binding1){
                super(binding1.getRoot());
                this.binding1=binding1;
                binding1.coursesBtn.setVisibility(View.GONE);
                binding1.btnLyt.setVisibility(View.GONE);
                binding1.parentLayout.setOnClickListener(v->{
                    btn_vis = !btn_vis;
                    if(btn_vis)binding1.btnLyt.setVisibility(View.VISIBLE);
                    else binding1.btnLyt.setVisibility(View.GONE);
                });
            }
        }

        JSONArray data;
        public OptionAdapter(){
            data = new JSONArray();
        }
        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            RecyclerView.ViewHolder holder;
            if(viewType==0||viewType==2){
                AdminTitleElementBinding titleElementBinding = AdminTitleElementBinding.inflate(
                        LayoutInflater.from(parent.getContext()),parent,false);
                holder = new VHtitle(titleElementBinding);
            }else{
                AdminHomeElementBinding binding1 = AdminHomeElementBinding.inflate(
                        LayoutInflater.from(parent.getContext()),parent,false
                );
                holder = new VHoption(binding1);
            }
            return holder;
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            int viewType = getItemViewType(position);
            if(viewType==0){
                VHtitle h = (VHtitle) holder;
                h.textView.setText("Courses");
            }else if(viewType==1) {
                VHoption p = (VHoption) holder;
                JSONObject object = data.optJSONObject(position - 1);
                p.binding1.title.setText(object.optString("code") + " - " + object.optString("name"));
                p.binding1.textView6.setVisibility(View.GONE);
            }
        }

        @Override
        public int getItemCount() {
            return data.length()+1;
        }
        @Override
        public int getItemViewType(int position){
            if(position==0)return 0;
            return 1;
        }
        public void updateData(){
            data = optionData.optJSONArray("data");
            notifyDataSetChanged();
        }
    }
}