package com.infsml.hachiman;

public class StateCodes {
    static final int state_ok=0;
    static final int state_invalid_login=1;
    static final int state_already_registered=2;
}
