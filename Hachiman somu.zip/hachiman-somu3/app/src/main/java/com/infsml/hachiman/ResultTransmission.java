package com.infsml.hachiman;

public class ResultTransmission {
    static String value;
    static int result = 0;
    static int prev = 0;
}
